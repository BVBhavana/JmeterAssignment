/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7472916666666667, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.82, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-6"], "isController": false}, {"data": [0.83, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-5"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-4"], "isController": false}, {"data": [0.84, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-3"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-2"], "isController": false}, {"data": [0.94, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-1"], "isController": false}, {"data": [0.8, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-0"], "isController": false}, {"data": [0.88, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-0"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-1"], "isController": false}, {"data": [0.22, 500, 1500, "Dashboard"], "isController": true}, {"data": [0.98, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-1"], "isController": false}, {"data": [0.86, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-2"], "isController": false}, {"data": [0.84, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-3"], "isController": false}, {"data": [0.92, 500, 1500, "Login-0"], "isController": false}, {"data": [0.86, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-4"], "isController": false}, {"data": [0.94, 500, 1500, "Login-1"], "isController": false}, {"data": [0.82, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-5"], "isController": false}, {"data": [0.98, 500, 1500, "Login-2"], "isController": false}, {"data": [0.82, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-6"], "isController": false}, {"data": [0.98, 500, 1500, "Login-3"], "isController": false}, {"data": [0.0, 500, 1500, "Recruitment"], "isController": true}, {"data": [0.98, 500, 1500, "Login-4"], "isController": false}, {"data": [0.96, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-5"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-5"], "isController": false}, {"data": [0.98, 500, 1500, "Login-5"], "isController": false}, {"data": [0.3, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule"], "isController": false}, {"data": [0.92, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-4"], "isController": false}, {"data": [0.88, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-6"], "isController": false}, {"data": [0.98, 500, 1500, "Login-6"], "isController": false}, {"data": [0.3, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-6"], "isController": false}, {"data": [0.9244444444444444, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-1"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.86, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-2"], "isController": false}, {"data": [0.82, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-3"], "isController": false}, {"data": [0.88, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-4"], "isController": false}, {"data": [0.0, 500, 1500, "Homepage-6"], "isController": false}, {"data": [0.0, 500, 1500, "Homepage-5"], "isController": false}, {"data": [0.02, 500, 1500, "Homepage-4"], "isController": false}, {"data": [0.0, 500, 1500, "ApplyLeave"], "isController": true}, {"data": [0.0, 500, 1500, "Homepage-3"], "isController": false}, {"data": [0.6, 500, 1500, "Homepage-2"], "isController": false}, {"data": [0.92, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-1"], "isController": false}, {"data": [0.84, 500, 1500, "Homepage-1"], "isController": false}, {"data": [0.88, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-0"], "isController": false}, {"data": [0.44, 500, 1500, "Homepage-0"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-3"], "isController": false}, {"data": [0.88, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-2"], "isController": false}, {"data": [0.98, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-2"], "isController": false}, {"data": [0.98, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-3"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-4"], "isController": false}, {"data": [0.98, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-5"], "isController": false}, {"data": [0.98, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-6"], "isController": false}, {"data": [0.44, 500, 1500, "Login"], "isController": false}, {"data": [0.82, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-0"], "isController": false}, {"data": [0.34, 500, 1500, "MyInfo"], "isController": true}, {"data": [0.86, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-6"], "isController": false}, {"data": [0.86, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-4"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-5"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-2"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-3"], "isController": false}, {"data": [0.84, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-0"], "isController": false}, {"data": [0.38, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList"], "isController": false}, {"data": [0.46, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule"], "isController": false}, {"data": [0.94, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-0"], "isController": false}, {"data": [0.98, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-1"], "isController": false}, {"data": [0.36, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy"], "isController": false}, {"data": [0.35, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave"], "isController": false}, {"data": [0.0, 500, 1500, "Leave"], "isController": true}, {"data": [0.4, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-3"], "isController": false}, {"data": [0.92, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-2"], "isController": false}, {"data": [0.0, 500, 1500, "Homepage"], "isController": false}, {"data": [0.98, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-1"], "isController": false}, {"data": [0.88, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-0"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-6"], "isController": false}, {"data": [0.92, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-5"], "isController": false}, {"data": [0.88, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-4"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2250, 0, 0.0, 629.5617777777778, 0, 11847, 344.0, 1174.7000000000003, 2140.699999999999, 4273.729999999983, 8.420942322159055, 692.4821094448822, 8.948804559519221], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-6", 50, 0, 0.0, 376.47999999999996, 185, 795, 276.5, 679.4, 697.3999999999999, 795.0, 0.5096580194689363, 0.49472663217980734, 0.3414310560114163], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-5", 50, 0, 0.0, 377.11999999999995, 178, 876, 263.0, 661.0, 750.9999999999997, 876.0, 0.5095956867821071, 0.4946661256459125, 0.34636581835971336], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-4", 50, 0, 0.0, 356.25999999999993, 182, 878, 229.0, 662.0999999999999, 736.1499999999995, 878.0, 0.5096839959225281, 0.49425410932721714, 0.3419461964831805], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-3", 50, 0, 0.0, 360.2000000000001, 176, 878, 223.0, 640.7, 725.3499999999999, 878.0, 0.5096372402124167, 0.49420876907317374, 0.346891754324272], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-2", 50, 0, 0.0, 360.68, 185, 876, 233.5, 673.1, 750.9999999999997, 876.0, 0.5095956867821071, 0.49317316953229307, 0.3408916459431087], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-1", 50, 0, 0.0, 442.38, 339, 1457, 382.5, 513.9, 867.5499999999984, 1457.0, 0.5082850462539392, 2.140684167556165, 0.2923631760191115], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-0", 25, 0, 0.0, 499.87999999999994, 275, 1001, 349.0, 858.4000000000001, 961.0999999999999, 1001.0, 0.2428033098947205, 0.3888646760032633, 0.14511291567926654], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-0", 25, 0, 0.0, 439.84000000000003, 268, 978, 322.0, 888.0000000000002, 975.3, 978.0, 0.20308197200718098, 0.3252484707927508, 0.11820005401980456], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-1", 25, 0, 0.0, 372.52000000000004, 338, 423, 376.0, 402.40000000000003, 419.7, 423.0, 0.24264777249344852, 1.0220873926283607, 0.13956986132679802], "isController": false}, {"data": ["Dashboard", 25, 0, 0.0, 1707.3999999999999, 1136, 3274, 1626.0, 2315.6000000000004, 3002.499999999999, 3274.0, 0.22612156295224312, 2.642265794591172, 1.1526899986432706], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-1", 25, 0, 0.0, 399.6, 334, 525, 378.0, 484.8, 514.1999999999999, 525.0, 0.20294843486167036, 0.8544287661141058, 0.11673498841164437], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-2", 25, 0, 0.0, 370.92, 187, 1047, 220.0, 887.0000000000003, 1026.8999999999999, 1047.0, 0.24309843541846965, 0.23526420849580412, 0.16261955884926924], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-3", 25, 0, 0.0, 378.64000000000004, 186, 1047, 212.0, 879.2000000000004, 1026.8999999999999, 1047.0, 0.24309843541846965, 0.23573901012748083, 0.16546836863932943], "isController": false}, {"data": ["Login-0", 25, 0, 0.0, 457.96, 309, 1859, 354.0, 832.000000000001, 1637.2999999999995, 1859.0, 0.5258950734149522, 0.8422538285161345, 0.4370475658946527], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-4", 25, 0, 0.0, 355.64, 183, 664, 253.0, 633.0, 655.6, 664.0, 0.2431126194898525, 0.23575276479826515, 0.16310387655227407], "isController": false}, {"data": ["Login-1", 25, 0, 0.0, 453.03999999999996, 340, 1281, 382.0, 806.8000000000004, 1174.1999999999998, 1281.0, 0.5289326139849783, 2.2952989461017665, 0.32954981222892205], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-5", 25, 0, 0.0, 397.0, 179, 1047, 232.0, 881.0000000000003, 1026.8999999999999, 1047.0, 0.24306534568753463, 0.23594429063809516, 0.1652084771469962], "isController": false}, {"data": ["Login-2", 25, 0, 0.0, 251.88000000000002, 185, 516, 213.0, 382.2000000000001, 483.5999999999999, 516.0, 0.5408094836351051, 0.5233810530101456, 0.38765054784000696], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-6", 25, 0, 0.0, 406.96000000000004, 185, 1047, 233.0, 901.4000000000003, 1026.8999999999999, 1047.0, 0.24304171568007932, 0.23592135291601452, 0.16281896187161565], "isController": false}, {"data": ["Login-3", 25, 0, 0.0, 251.12000000000003, 189, 527, 215.0, 382.2000000000001, 491.2999999999999, 527.0, 0.5408094836351051, 0.5244373215328705, 0.39398815897635586], "isController": false}, {"data": ["Recruitment", 25, 0, 0.0, 3241.04, 2395, 4823, 3330.0, 4072.6000000000013, 4704.799999999999, 4823.0, 0.2717361767806872, 6.352491243301703, 2.778130893278334], "isController": true}, {"data": ["Login-4", 25, 0, 0.0, 250.60000000000002, 187, 527, 211.0, 382.2000000000001, 491.2999999999999, 527.0, 0.5408094836351051, 0.5244373215328705, 0.38870681636273174], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-5", 25, 0, 0.0, 259.72, 183, 636, 210.0, 489.60000000000025, 610.8, 636.0, 0.22922741193082835, 0.22251176509691736, 0.1558030065467349], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-5", 25, 0, 0.0, 322.72, 189, 649, 262.0, 626.4000000000001, 645.1, 649.0, 0.20378551981610396, 0.19781524091524152, 0.13851047050000814], "isController": false}, {"data": ["Login-5", 25, 0, 0.0, 252.63999999999993, 188, 517, 211.0, 382.2000000000001, 484.29999999999995, 517.0, 0.5408094836351051, 0.5249654557942328, 0.3934600247149934], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule", 25, 0, 0.0, 1313.0, 831, 2196, 991.0, 2060.2000000000003, 2163.9, 2196.0, 0.24144325117824306, 2.5743698029340183, 1.096869145001159], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-4", 25, 0, 0.0, 295.48, 180, 959, 207.0, 605.2, 854.2999999999997, 959.0, 0.2299061982711054, 0.22294614734688248, 0.1542437091916498], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-6", 25, 0, 0.0, 334.76, 190, 651, 270.0, 601.8, 636.5999999999999, 651.0, 0.20378551981610396, 0.19781524091524152, 0.13652037753305402], "isController": false}, {"data": ["Login-6", 25, 0, 0.0, 252.11999999999995, 192, 517, 210.0, 382.2000000000001, 484.29999999999995, 517.0, 0.5408094836351051, 0.5249654557942328, 0.38817868210136935], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 25, 0, 0.0, 1326.4, 826, 2453, 1236.0, 2002.6000000000001, 2330.2999999999997, 2453.0, 0.20263588762624216, 2.159655296091559, 0.9170065461523498], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-6", 25, 0, 0.0, 311.48, 183, 959, 210.0, 624.2, 863.5999999999998, 959.0, 0.22904050352264294, 0.222330332521003, 0.15343924357083308], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 225, 0, 0.0, 421.95111111111106, 305, 1614, 339.0, 759.6, 882.7999999999997, 1465.940000000004, 0.8826229199519854, 9.931476895383685, 0.4990612018087886], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-1", 25, 0, 0.0, 449.12, 337, 1230, 365.0, 681.2000000000004, 1095.5999999999997, 1230.0, 0.2036427617216774, 0.8568507843300968, 0.11713436196686325], "isController": false}, {"data": ["Test", 25, 0, 0.0, 7656.28, 5357, 13887, 7120.0, 10962.000000000007, 13666.5, 13887.0, 0.7279079924297568, 2662.1372117939295, 6.944270681685835], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-2", 25, 0, 0.0, 351.35999999999996, 188, 636, 291.0, 628.8, 634.2, 636.0, 0.20378551981610396, 0.1972182130251553, 0.1363213682363586], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-3", 25, 0, 0.0, 389.7199999999999, 183, 921, 306.0, 640.4, 838.7999999999998, 921.0, 0.20378551981610396, 0.1976162316185461, 0.13870947979670356], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-4", 25, 0, 0.0, 333.4000000000001, 189, 636, 270.0, 617.8000000000001, 634.5, 636.0, 0.20378551981610396, 0.1976162316185461, 0.13671938682974943], "isController": false}, {"data": ["Homepage-6", 25, 0, 0.0, 3255.4, 2066, 4347, 3238.0, 4092.8, 4278.3, 4347.0, 0.8516146613980107, 1213.9068408076712, 0.49649800083458234], "isController": false}, {"data": ["Homepage-5", 25, 0, 0.0, 3577.52, 2306, 10151, 3137.0, 6146.600000000011, 9892.699999999999, 10151.0, 0.8538834619851083, 967.6842800588327, 0.5061594349853132], "isController": false}, {"data": ["Homepage-4", 25, 0, 0.0, 2185.8, 1465, 2828, 2138.0, 2727.2000000000003, 2826.2, 2828.0, 0.8795074758135445, 420.1219973065083, 0.5144775175901495], "isController": false}, {"data": ["ApplyLeave", 25, 0, 0.0, 3095.1200000000003, 2431, 5033, 2945.0, 3955.400000000002, 4858.4, 5033.0, 0.2894858730893932, 6.7680553243689205, 2.9533778478172765], "isController": true}, {"data": ["Homepage-3", 25, 0, 0.0, 2258.6399999999994, 1596, 3278, 2160.0, 2859.6, 3160.3999999999996, 3278.0, 0.8722654478210808, 444.9064876923345, 0.5187594313701546], "isController": false}, {"data": ["Homepage-2", 25, 0, 0.0, 733.7199999999999, 201, 1773, 715.0, 1485.0000000000005, 1716.3, 1773.0, 0.9253775540420491, 1.5127754154945219, 0.541309721553894], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-1", 25, 0, 0.0, 442.32000000000005, 333, 1134, 379.0, 694.4000000000005, 1053.6, 1134.0, 0.22930730848253594, 0.9654106406616891, 0.13189648896114617], "isController": false}, {"data": ["Homepage-1", 25, 0, 0.0, 541.4000000000001, 341, 1291, 434.0, 956.4000000000002, 1211.4999999999998, 1291.0, 0.9037995734066013, 3.894775981978236, 0.47396520597592273], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-0", 25, 0, 0.0, 439.28, 271, 916, 316.0, 870.4, 903.4, 916.0, 0.23047634851711518, 0.36912227692194227, 0.1361701082547409], "isController": false}, {"data": ["Homepage-0", 25, 0, 0.0, 1183.5200000000002, 812, 2370, 1124.0, 1754.8000000000002, 2210.0999999999995, 2370.0, 0.8430565859580494, 0.8677555093747893, 0.4223515904262494], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-3", 25, 0, 0.0, 310.04, 179, 959, 202.0, 634.4000000000001, 867.1999999999998, 959.0, 0.22922741193082835, 0.22228791020245364, 0.1560268614411986], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-2", 25, 0, 0.0, 330.43999999999994, 188, 959, 211.0, 622.4000000000001, 861.7999999999997, 959.0, 0.2290530945073068, 0.22167150064134866, 0.15322399388428237], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-2", 25, 0, 0.0, 259.28, 180, 575, 213.0, 453.6000000000001, 547.4, 575.0, 0.3552095025646126, 0.3437623213296202, 0.23761573169605432], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-3", 25, 0, 0.0, 256.96, 180, 595, 216.0, 441.00000000000017, 561.3999999999999, 595.0, 0.355108592207497, 0.34435823443559044, 0.2417096570006108], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-4", 25, 0, 0.0, 244.92000000000004, 192, 485, 209.0, 418.80000000000007, 471.79999999999995, 485.0, 0.3571479592565608, 0.3463358628337548, 0.23961000782154032], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-5", 25, 0, 0.0, 256.08, 179, 598, 210.0, 435.6000000000002, 563.4999999999999, 598.0, 0.35509346059882957, 0.3446903318703483, 0.24135258650076702], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-6", 25, 0, 0.0, 257.68000000000006, 188, 593, 212.0, 447.60000000000014, 559.9999999999999, 593.0, 0.35511868066307756, 0.3447148130655265, 0.23790177239733518], "isController": false}, {"data": ["Login", 25, 0, 0.0, 1170.24, 857, 3119, 969.0, 2265.0, 2878.9999999999995, 3119.0, 0.5192000166144005, 5.602005929264189, 2.6289571153766276], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-0", 25, 0, 0.0, 474.84, 276, 1050, 331.0, 871.0000000000002, 1020.5999999999999, 1050.0, 0.20411995721645698, 0.32691086897948185, 0.11840552205720258], "isController": false}, {"data": ["MyInfo", 25, 0, 0.0, 1574.5199999999998, 1145, 2523, 1397.0, 2421.6000000000004, 2506.8, 2523.0, 0.2018179763307877, 2.358771248910183, 1.0291928441400133], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-6", 25, 0, 0.0, 375.64, 188, 939, 242.0, 783.2000000000003, 916.1999999999999, 939.0, 0.20304568527918782, 0.1970970812182741, 0.1360247461928934], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-4", 25, 0, 0.0, 372.28000000000003, 188, 939, 242.0, 774.8000000000003, 916.1999999999999, 939.0, 0.20304568527918782, 0.19689879441624367, 0.13622303299492386], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-5", 25, 0, 0.0, 339.8, 187, 939, 242.0, 743.6000000000004, 916.1999999999999, 939.0, 0.20304568527918782, 0.1970970812182741, 0.13800761421319796], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-2", 25, 0, 0.0, 341.08000000000004, 184, 939, 216.0, 781.4000000000003, 916.1999999999999, 939.0, 0.20304568527918782, 0.19650222081218274, 0.13582645939086294], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-3", 25, 0, 0.0, 317.1200000000001, 188, 723, 220.0, 662.8, 705.3, 723.0, 0.20304568527918782, 0.19689879441624367, 0.13820590101522842], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-0", 50, 0, 0.0, 452.2, 280, 1220, 318.0, 781.5999999999999, 848.1999999999998, 1220.0, 0.5084711290092948, 0.8143482925539488, 0.295449532969268], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList", 25, 0, 0.0, 1188.12, 818, 3182, 946.0, 1829.8000000000002, 2791.099999999999, 3182.0, 0.27208811301451863, 2.900788766434122, 1.2328992620970374], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule", 25, 0, 0.0, 1034.32, 834, 2249, 936.0, 1478.0000000000005, 2055.4999999999995, 2249.0, 0.3516273312892064, 3.749034123674365, 1.5933113449042167], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-0", 25, 0, 0.0, 349.12000000000006, 276, 661, 312.0, 517.4, 618.9999999999999, 661.0, 0.3563537880407669, 0.5707228636590407, 0.20880104768013683], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-1", 25, 0, 0.0, 417.12, 344, 1292, 383.0, 418.40000000000003, 1031.8999999999994, 1292.0, 0.35613550243596687, 1.4999564846932962, 0.20484747161600048], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy", 25, 0, 0.0, 1236.88, 841, 2205, 1042.0, 1966.8, 2133.8999999999996, 2205.0, 0.22731405710129116, 2.4232388843426076, 1.0311267531596653], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave", 50, 0, 0.0, 1319.38, 869, 3020, 1173.5, 1887.8, 2388.749999999996, 3020.0, 0.505510059650187, 5.389635701016076, 2.2881241469517746], "isController": false}, {"data": ["Leave", 25, 0, 0.0, 3231.1199999999994, 2447, 5361, 3222.0, 4281.200000000001, 5124.9, 5361.0, 0.514011966198573, 12.015812774996402, 5.244026377809075], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails", 25, 0, 0.0, 1222.64, 828, 2198, 1060.0, 2046.8000000000004, 2181.8, 2198.0, 0.20195329224257014, 2.1528773169091453, 0.9143119754263235], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-3", 25, 0, 0.0, 298.52000000000004, 191, 620, 208.0, 599.8000000000001, 616.1, 620.0, 0.27998969637917326, 0.2715134458051944, 0.1905789241955896], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-2", 25, 0, 0.0, 286.28000000000003, 186, 622, 214.0, 603.4000000000001, 620.2, 622.0, 0.27998969637917326, 0.2709665909294538, 0.18729779494114615], "isController": false}, {"data": ["Homepage", 25, 0, 0.0, 5577.560000000001, 3710, 11847, 5131.0, 8967.800000000008, 11732.4, 11847.0, 0.7672712764324955, 2726.4241214264343, 3.0428600132737933], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-1", 25, 0, 0.0, 415.32, 329, 1232, 365.0, 468.20000000000005, 1008.7999999999995, 1232.0, 0.2780094523213789, 1.1707021476230193, 0.15990973380594942], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-0", 25, 0, 0.0, 442.36, 277, 1328, 309.0, 842.0, 1184.8999999999996, 1328.0, 0.275085001265391, 0.4405658223391028, 0.16118261792894004], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-6", 25, 0, 0.0, 300.28000000000003, 186, 615, 208.0, 608.2, 613.5, 615.0, 0.27998969637917326, 0.27178687324306466, 0.18757122237901644], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-5", 25, 0, 0.0, 285.72, 186, 677, 207.0, 610.6, 658.6999999999999, 677.0, 0.281224338279132, 0.2729853439936106, 0.19114466742409755], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-4", 25, 0, 0.0, 317.71999999999997, 189, 628, 211.0, 610.2, 624.1, 628.0, 0.27988625422628244, 0.27141313520185395, 0.18777525063814066], "isController": false}, {"data": ["Debug Sampler", 25, 0, 0.0, 0.12000000000000002, 0, 2, 0.0, 0.40000000000000213, 1.6999999999999993, 2.0, 0.20332642023504535, 0.15631512799398153, 0.0], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2250, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
