/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.696875, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-6"], "isController": false}, {"data": [0.825, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-5"], "isController": false}, {"data": [0.775, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-4"], "isController": false}, {"data": [0.775, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-3"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-2"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-1"], "isController": false}, {"data": [0.65, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-0"], "isController": false}, {"data": [0.75, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-0"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-1"], "isController": false}, {"data": [0.05, 500, 1500, "Dashboard"], "isController": true}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-1"], "isController": false}, {"data": [0.6, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-2"], "isController": false}, {"data": [0.7, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-3"], "isController": false}, {"data": [0.85, 500, 1500, "Login-0"], "isController": false}, {"data": [0.65, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-4"], "isController": false}, {"data": [0.95, 500, 1500, "Login-1"], "isController": false}, {"data": [0.65, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-5"], "isController": false}, {"data": [0.95, 500, 1500, "Login-2"], "isController": false}, {"data": [0.75, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-6"], "isController": false}, {"data": [0.95, 500, 1500, "Login-3"], "isController": false}, {"data": [0.0, 500, 1500, "Recruitment"], "isController": true}, {"data": [0.95, 500, 1500, "Login-4"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-5"], "isController": false}, {"data": [0.8, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-5"], "isController": false}, {"data": [0.95, 500, 1500, "Login-5"], "isController": false}, {"data": [0.1, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-4"], "isController": false}, {"data": [0.8, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-6"], "isController": false}, {"data": [0.95, 500, 1500, "Login-6"], "isController": false}, {"data": [0.25, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-6"], "isController": false}, {"data": [0.8555555555555555, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-1"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.8, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-2"], "isController": false}, {"data": [0.75, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-3"], "isController": false}, {"data": [0.75, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-4"], "isController": false}, {"data": [0.0, 500, 1500, "Homepage-6"], "isController": false}, {"data": [0.0, 500, 1500, "Homepage-5"], "isController": false}, {"data": [0.0, 500, 1500, "Homepage-4"], "isController": false}, {"data": [0.0, 500, 1500, "ApplyLeave"], "isController": true}, {"data": [0.0, 500, 1500, "Homepage-3"], "isController": false}, {"data": [0.6, 500, 1500, "Homepage-2"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-1"], "isController": false}, {"data": [0.65, 500, 1500, "Homepage-1"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-0"], "isController": false}, {"data": [0.25, 500, 1500, "Homepage-0"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-3"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-2"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-2"], "isController": false}, {"data": [0.8, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-3"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-4"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-5"], "isController": false}, {"data": [0.85, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-6"], "isController": false}, {"data": [0.4, 500, 1500, "Login"], "isController": false}, {"data": [0.65, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-0"], "isController": false}, {"data": [0.15, 500, 1500, "MyInfo"], "isController": true}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-6"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-4"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-5"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-2"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-3"], "isController": false}, {"data": [0.825, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-0"], "isController": false}, {"data": [0.4, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList"], "isController": false}, {"data": [0.3, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule"], "isController": false}, {"data": [0.8, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-0"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-1"], "isController": false}, {"data": [0.45, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy"], "isController": false}, {"data": [0.275, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave"], "isController": false}, {"data": [0.0, 500, 1500, "Leave"], "isController": true}, {"data": [0.35, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-3"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-2"], "isController": false}, {"data": [0.0, 500, 1500, "Homepage"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-1"], "isController": false}, {"data": [0.95, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-0"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-6"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-5"], "isController": false}, {"data": [0.9, 500, 1500, "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-4"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 900, 0, 0.0, 1021.171111111111, 0, 20178, 408.0, 1614.1999999999998, 3510.8999999999987, 13077.340000000004, 3.1777753454065256, 261.3202246974052, 3.3771931615157285], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-6", 20, 0, 0.0, 459.1500000000001, 190, 985, 322.5, 913.5000000000001, 981.8, 985.0, 0.22017459845657605, 0.21372417076741856, 0.14749977982540155], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-5", 20, 0, 0.0, 426.05, 191, 985, 303.5, 845.3000000000001, 978.05, 985.0, 0.22192878305351815, 0.21542696323749708, 0.1508422197316881], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-4", 20, 0, 0.0, 483.29999999999995, 195, 985, 364.0, 913.6000000000001, 981.8, 985.0, 0.22017459845657605, 0.2135091565111133, 0.1477147940817068], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-3", 20, 0, 0.0, 488.6, 195, 985, 364.0, 913.5000000000001, 981.8, 985.0, 0.22017459845657605, 0.2135091565111133, 0.14986493664475928], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-2", 20, 0, 0.0, 366.00000000000006, 195, 921, 268.5, 832.0000000000001, 916.9, 921.0, 0.22017459845657605, 0.21307912799850282, 0.14728476556909628], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-1", 20, 0, 0.0, 470.85, 337, 1384, 385.5, 619.6, 1345.7999999999995, 1384.0, 0.22154773245895829, 0.9330751032966302, 0.1274332172053969], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-0", 10, 0, 0.0, 839.0, 306, 1285, 855.0, 1282.5, 1285.0, 1285.0, 0.08479318941102651, 0.13580159241609716, 0.05067717960893381], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-0", 10, 0, 0.0, 558.4, 292, 1252, 520.0, 1196.9, 1252.0, 1252.0, 0.08941344778254649, 0.14320122496423462, 0.052041420779685266], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-1", 10, 0, 0.0, 477.29999999999995, 368, 676, 470.5, 668.3000000000001, 676.0, 676.0, 0.0847486355469677, 0.35700362724160145, 0.04874701790738669], "isController": false}, {"data": ["Dashboard", 10, 0, 0.0, 2089.4, 1206, 4252, 1794.0, 4107.200000000001, 4252.0, 4252.0, 0.08692175303791527, 1.0159828731550857, 0.44309721763468524], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-1", 10, 0, 0.0, 442.2, 365, 707, 407.5, 687.2, 707.0, 707.0, 0.08938387693627824, 0.37676526173833763, 0.051413187026824105], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-2", 10, 0, 0.0, 811.6, 285, 1593, 701.5, 1576.3000000000002, 1593.0, 1593.0, 0.08467830711128423, 0.08194941635476824, 0.056645156612529], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-3", 10, 0, 0.0, 697.1, 307, 1230, 598.5, 1226.0, 1230.0, 1230.0, 0.0846897813309846, 0.08212593052897237, 0.05764529061298464], "isController": false}, {"data": ["Login-0", 10, 0, 0.0, 438.3, 326, 722, 389.0, 704.0, 722.0, 722.0, 0.23826542768644268, 0.3815969740290684, 0.19875618000953063], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-4", 10, 0, 0.0, 766.7, 203, 1615, 602.5, 1582.5, 1615.0, 1615.0, 0.08467974121871083, 0.08211619436541003, 0.05681150607153745], "isController": false}, {"data": ["Login-1", 10, 0, 0.0, 414.40000000000003, 360, 705, 377.5, 676.8000000000001, 705.0, 705.0, 0.2392802450229709, 1.0395838692213821, 0.1490828089107963], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-5", 10, 0, 0.0, 772.0, 215, 1594, 669.5, 1558.5, 1594.0, 1594.0, 0.0847012586607037, 0.0822197764733784, 0.05757038674594705], "isController": false}, {"data": ["Login-2", 10, 0, 0.0, 322.8, 190, 628, 302.5, 607.2, 628.0, 628.0, 0.24212488801723928, 0.2343220351807462, 0.17355436309048206], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule-6", 10, 0, 0.0, 603.5, 204, 1678, 371.0, 1621.5000000000002, 1678.0, 1678.0, 0.08495094083166971, 0.08246214373699189, 0.05691049356496623], "isController": false}, {"data": ["Login-3", 10, 0, 0.0, 325.1, 201, 640, 301.5, 618.0000000000001, 640.0, 640.0, 0.2420545590976206, 0.23472673553118872, 0.1763405284051025], "isController": false}, {"data": ["Recruitment", 10, 0, 0.0, 4405.5, 2909, 5922, 4317.5, 5840.700000000001, 5922.0, 5922.0, 0.10582794492713746, 2.473893568835787, 1.0819460502365255], "isController": true}, {"data": ["Login-4", 10, 0, 0.0, 322.0, 198, 627, 301.0, 606.3000000000001, 627.0, 627.0, 0.24213075060532688, 0.23480062046004843, 0.1740314769975787], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-5", 10, 0, 0.0, 245.8, 196, 323, 238.5, 321.3, 323.0, 323.0, 0.08812280794515236, 0.08554108505613424, 0.05989597102522075], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-5", 10, 0, 0.0, 460.40000000000003, 207, 1151, 306.5, 1106.9, 1151.0, 1151.0, 0.0822010143605172, 0.07979278151792393, 0.05587100194816404], "isController": false}, {"data": ["Login-5", 10, 0, 0.0, 322.4, 188, 623, 301.5, 602.7, 623.0, 623.0, 0.242142476633251, 0.2350484587631362, 0.17616811044118358], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewRecruitmentModule", 10, 0, 0.0, 2285.6, 1188, 3490, 2042.5, 3469.1, 3490.0, 3490.0, 0.08411277841329655, 0.8968689281088082, 0.38212172380728077], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-4", 10, 0, 0.0, 311.9, 191, 922, 245.0, 862.1000000000003, 922.0, 922.0, 0.08812280794515236, 0.0854550276265003, 0.05912145415851531], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-6", 10, 0, 0.0, 514.7, 200, 1202, 306.5, 1196.9, 1202.0, 1202.0, 0.0822010143605172, 0.07979278151792393, 0.055068257667299614], "isController": false}, {"data": ["Login-6", 10, 0, 0.0, 322.79999999999995, 190, 625, 302.0, 604.5000000000001, 625.0, 625.0, 0.2420545590976206, 0.2349631169365575, 0.17374033294604602], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 10, 0, 0.0, 1712.6, 883, 3828, 1425.0, 3683.5000000000005, 3828.0, 3828.0, 0.08165931732810713, 0.8705808274130329, 0.3695403090805161], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-6", 10, 0, 0.0, 310.0, 189, 922, 244.5, 862.1000000000003, 922.0, 922.0, 0.08812358451492372, 0.08554183887483807, 0.05903591696995867], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 90, 0, 0.0, 498.1777777777779, 305, 2949, 360.5, 905.1000000000004, 1029.0, 2949.0, 0.33200408733920855, 3.7359321913929784, 0.1877249673529314], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-1", 10, 0, 0.0, 455.29999999999995, 359, 613, 438.0, 607.4, 613.0, 613.0, 0.0821051767313929, 0.34573976764234987, 0.04722651278788127], "isController": false}, {"data": ["Test", 10, 0, 0.0, 14992.099999999999, 9854, 22252, 14392.0, 21982.2, 22252.0, 22252.0, 0.39599255533995964, 1448.2462479705382, 3.779021923137845], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-2", 10, 0, 0.0, 517.3, 207, 1253, 307.0, 1243.2, 1253.0, 1253.0, 0.0822010143605172, 0.0795519582336646, 0.05498798323921317], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-3", 10, 0, 0.0, 568.8000000000001, 207, 1625, 348.0, 1577.6000000000001, 1625.0, 1625.0, 0.0822010143605172, 0.07971250708983749, 0.05595127637625048], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-4", 10, 0, 0.0, 515.8, 203, 1625, 348.0, 1532.3000000000002, 1625.0, 1625.0, 0.0822010143605172, 0.07971250708983749, 0.05514853209538605], "isController": false}, {"data": ["Homepage-6", 10, 0, 0.0, 9489.199999999999, 5593, 18701, 9476.0, 18004.800000000003, 18701.0, 18701.0, 0.4971908715755978, 708.7048022423309, 0.28986616243225777], "isController": false}, {"data": ["Homepage-5", 10, 0, 0.0, 8933.5, 2864, 17323, 8314.0, 17165.9, 17323.0, 17323.0, 0.5337603416066187, 604.8969383840406, 0.3163989524953296], "isController": false}, {"data": ["Homepage-4", 10, 0, 0.0, 5187.6, 2059, 15431, 3692.5, 14599.000000000004, 15431.0, 15431.0, 0.5937889674009856, 283.64034851701206, 0.3473433510480375], "isController": false}, {"data": ["ApplyLeave", 10, 0, 0.0, 3340.2999999999997, 2547, 4813, 2966.5, 4794.2, 4813.0, 4813.0, 0.1341363630266529, 3.1354898827648188, 1.3684790864642995], "isController": true}, {"data": ["Homepage-3", 10, 0, 0.0, 5723.9, 3482, 15300, 4077.0, 14553.300000000003, 15300.0, 15300.0, 0.5984440454817475, 305.2415282764811, 0.3559105700179533], "isController": false}, {"data": ["Homepage-2", 10, 0, 0.0, 890.5999999999999, 240, 2290, 712.5, 2193.6000000000004, 2290.0, 2290.0, 1.1721955222131053, 1.9162649454929082, 0.6856885916070801], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-1", 10, 0, 0.0, 406.59999999999997, 347, 511, 408.0, 505.0, 511.0, 511.0, 0.08809098036452047, 0.37077355993269845, 0.050669518979201716], "isController": false}, {"data": ["Homepage-1", 10, 0, 0.0, 558.8000000000001, 341, 764, 543.0, 761.4, 764.0, 764.0, 1.1669973159061733, 5.032561960263741, 0.6119898033609522], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-0", 10, 0, 0.0, 463.90000000000003, 280, 905, 411.5, 875.2, 905.0, 905.0, 0.08806460419363644, 0.1410409676538709, 0.0520303569698731], "isController": false}, {"data": ["Homepage-0", 10, 0, 0.0, 1718.3000000000002, 1130, 2423, 1549.0, 2408.8, 2423.0, 2423.0, 0.9670244657189827, 0.9953552606130935, 0.4844565926892951], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-3", 10, 0, 0.0, 310.79999999999995, 189, 922, 245.0, 862.1000000000003, 922.0, 922.0, 0.08812280794515236, 0.0854550276265003, 0.05998202845485469], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy-2", 10, 0, 0.0, 312.20000000000005, 188, 922, 244.5, 862.1000000000003, 922.0, 922.0, 0.08812358451492372, 0.08528366431082951, 0.05894985878195581], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-2", 10, 0, 0.0, 431.4, 199, 798, 359.5, 790.3000000000001, 798.0, 798.0, 0.16833316500016834, 0.1629083657374676, 0.11260568166515167], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-3", 10, 0, 0.0, 483.69999999999993, 207, 934, 359.0, 920.8000000000001, 934.0, 934.0, 0.16833316500016834, 0.16323714145035856, 0.11457833594249739], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-4", 10, 0, 0.0, 432.1, 194, 802, 359.0, 793.9000000000001, 802.0, 802.0, 0.16833316500016834, 0.16323714145035856, 0.11293445737804263], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-5", 10, 0, 0.0, 332.20000000000005, 203, 703, 297.0, 675.7, 703.0, 703.0, 0.16979081771257812, 0.16481647734990493, 0.11540469641401793], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-6", 10, 0, 0.0, 431.29999999999995, 203, 792, 359.0, 784.9, 792.0, 792.0, 0.16833316500016834, 0.16340152930680402, 0.11277006952159714], "isController": false}, {"data": ["Login", 10, 0, 0.0, 1182.6, 890, 1894, 1077.0, 1858.9, 1894.0, 1894.0, 0.2349127299208344, 2.535841626242101, 1.1902092044680401], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index-0", 10, 0, 0.0, 651.0, 306, 1773, 563.0, 1679.8000000000002, 1773.0, 1773.0, 0.08224022369340844, 0.13171285825897447, 0.04770575475965295], "isController": false}, {"data": ["MyInfo", 10, 0, 0.0, 1890.4, 1241, 3358, 1775.0, 3239.6000000000004, 3358.0, 3358.0, 0.0818062827225131, 0.9565343407436192, 0.4171800863056283], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-6", 10, 0, 0.0, 427.8, 207, 1227, 307.0, 1164.6000000000004, 1227.0, 1227.0, 0.0894822556687009, 0.08686070520965693, 0.059946120496805484], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-4", 10, 0, 0.0, 432.09999999999997, 196, 1278, 307.0, 1210.5000000000002, 1278.0, 1278.0, 0.0894822556687009, 0.08677332019435545, 0.06003350551210695], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-5", 10, 0, 0.0, 432.2, 196, 1278, 307.0, 1210.5000000000002, 1278.0, 1278.0, 0.0894822556687009, 0.08686070520965693, 0.060819970649820136], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-2", 10, 0, 0.0, 336.2, 210, 603, 307.0, 586.3000000000001, 603.0, 603.0, 0.0894822556687009, 0.08659855016375252, 0.05985873548150401], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails-3", 10, 0, 0.0, 427.09999999999997, 202, 1227, 307.0, 1164.6000000000004, 1227.0, 1227.0, 0.0894822556687009, 0.08677332019435545, 0.06090735566512161], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave-0", 20, 0, 0.0, 558.6, 276, 1258, 366.5, 1123.9000000000003, 1251.8, 1258.0, 0.22429822692251616, 0.3592276290555923, 0.13032953615126672], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList", 10, 0, 0.0, 1197.6999999999998, 905, 2349, 1017.0, 2270.0, 2349.0, 2349.0, 0.1080345278350961, 1.151506693414215, 0.48953145425277916], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule", 10, 0, 0.0, 1440.1000000000001, 863, 3036, 1077.5, 2926.7000000000003, 3036.0, 3036.0, 0.16197217318064755, 1.7264904983073908, 0.7339364097248093], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-0", 10, 0, 0.0, 496.6, 267, 1226, 316.5, 1172.5000000000002, 1226.0, 1226.0, 0.1648723063986942, 0.2640533032166587, 0.09660486703048489], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveModule-1", 10, 0, 0.0, 455.9, 341, 1101, 368.0, 1037.0000000000002, 1101.0, 1101.0, 0.16725204883759826, 0.703961260244188, 0.09620259449740759], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy", 10, 0, 0.0, 1188.2, 838, 2261, 1053.0, 2167.6000000000004, 2261.0, 2261.0, 0.08749671887304226, 0.9326432485344299, 0.396896737466095], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave", 20, 0, 0.0, 1521.6499999999999, 836, 2646, 1225.0, 2367.3, 2632.1, 2646.0, 0.21864375280137308, 2.331139550741749, 0.9896619084319963], "isController": false}, {"data": ["Leave", 10, 0, 0.0, 3894.6, 2765, 5006, 3923.5, 4946.6, 5006.0, 5006.0, 0.23280718908599898, 5.441981720270522, 2.3751335003724914], "isController": true}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewMyDetails", 10, 0, 0.0, 1435.6, 907, 2935, 1296.0, 2810.8, 2935.0, 2935.0, 0.08892762180860997, 0.9484426133382541, 0.4026059127975741], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-3", 10, 0, 0.0, 319.7, 207, 704, 261.5, 679.9000000000001, 704.0, 704.0, 0.1096058573370161, 0.10628771126529002, 0.0746047681288088], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-2", 10, 0, 0.0, 390.5, 196, 1022, 261.5, 992.4000000000001, 1022.0, 1022.0, 0.1096058573370161, 0.10607363732517865, 0.07332032448814065], "isController": false}, {"data": ["Homepage", 10, 0, 0.0, 12643.0, 7499, 20178, 12335.5, 19937.3, 20178.0, 20178.0, 0.4326007959854646, 1537.2063299635533, 1.7156170239228241], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-1", 10, 0, 0.0, 419.0, 349, 590, 391.0, 579.8000000000001, 590.0, 590.0, 0.10939482781254102, 0.4603877055255327, 0.06292339216951823], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-0", 10, 0, 0.0, 380.29999999999995, 279, 917, 332.0, 860.2000000000003, 917.0, 917.0, 0.10874411422481758, 0.1741604954381844, 0.06371725442860406], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-6", 10, 0, 0.0, 393.9, 208, 1022, 261.5, 993.2, 1022.0, 1022.0, 0.1096058573370161, 0.1063947482353457, 0.07342736145819632], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-5", 10, 0, 0.0, 388.79999999999995, 188, 1022, 261.0, 992.9000000000001, 1022.0, 1022.0, 0.1096058573370161, 0.1063947482353457, 0.07449773115875312], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewMyLeaveList-4", 10, 0, 0.0, 395.0, 198, 1022, 261.0, 993.8000000000001, 1022.0, 1022.0, 0.1096058573370161, 0.10628771126529002, 0.073534398428252], "isController": false}, {"data": ["Debug Sampler", 10, 0, 0.0, 0.2, 0, 1, 0.0, 1.0, 1.0, 1.0, 0.08966760219864961, 0.06970255014660653, 0.0], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 900, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
